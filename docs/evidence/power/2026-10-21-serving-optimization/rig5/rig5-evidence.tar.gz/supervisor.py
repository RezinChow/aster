#!/usr/bin/env python3
"""Isolated GPU5 NP1/NP4 geometry supervisor. No formal campaign is run here."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,socket,subprocess,sys,time,urllib.request,uuid,shutil,fcntl
ROOT=Path('/code/Power/.git/optimization-20261021')
RUN=ROOT/'rig5'
HERE=RUN/'supervisor.py'
KEY=ROOT/'benchmark.key'
ENGINE=Path('/data/prism/llama-prism-b10787-73bfe6c/llama-server')
MODEL='/data/models/Ternary-Bonsai-2-27B-PTQ1_0.gguf'
GPU=5;PORT=19120;LIMIT=.90
POWER_SHA='038e96fb23cab83fdbb7122df52ffda22e95daef59d316b64f3ad74967ba1093'
GW_SHA='eaf9f4ca8baf38074d1548badebbd3b42bd08ab5174e2f9136101ccbcfb6c1fd'
BASE=json.loads((ROOT/'candidate-provenance.json').read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 p=Path(p);t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(v,indent=2)+'\n');os.replace(t,p)
def unique(prefix):return RUN/(prefix+'-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
def env():
 keep={'PATH','LANG','LC_ALL','LC_CTYPE','TZ','HOME','USER','LOGNAME','LD_LIBRARY_PATH'}
 return {k:v for k,v in os.environ.items() if k in keep}
def request(path,body=None,key=False,timeout=3):
 headers={'Content-Type':'application/json'}
 if key:headers['Authorization']='Bearer '+KEY.read_text().strip()
 req=urllib.request.Request(path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
 with urllib.request.urlopen(req,timeout=timeout) as r:
  raw=r.read(2*1024*1024)
  if len(raw)>=2*1024*1024:raise RuntimeError('response byte bound')
  return r.status,json.loads(raw)
def gpu():
 r=subprocess.run(['nvidia-smi','-i',str(GPU),'--query-gpu=memory.used,memory.total,utilization.gpu,temperature.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=5,check=True)
 vals=[float(x.strip()) for x in r.stdout.strip().split(',')]
 return dict(zip(['used_mib','total_mib','util_pct','temperature_c'],vals))
def flags(arm):
 if arm not in ('baseline','candidate'):raise ValueError('unknown closed rig profile')
 n=1 if arm=='baseline' else 4
 return {'--host':'127.0.0.1','--port':str(PORT),'-m':MODEL,'-ngl':'99','-c':str(n*32768),'-fa':'on','--reasoning':'off','--alias':'prism27b','-t':'8','--parallel':str(n),'--jinja':True,'--cache-prompt':True,'--metrics':True,'--slots':True,'--cont-batching':True,'--spec-type':'none'}
def engine_argv(arm):
 a=[str(ENGINE)]
 for k,v in flags(arm).items():
  a.append(k)
  if v is not True:a.append(str(v))
 return a
def argv(kind,arm):
 if kind=='engine':return engine_argv(arm)
 if kind=='power':return [str(RUN/(arm+'-power')),'serve','--config',str(RUN/(arm+'.acl'))]
 return [str(RUN/('gateway-'+arm)),'--config',str(RUN/('gateway-'+arm+'.acl')),'--log-level','warn']
def pidfile(kind,arm):
 return RUN/('engine.pid' if kind=='engine' else ('' if kind=='power' else 'gateway-')+arm+'.pid')
def proc_args(pid):
 p=Path('/proc',str(pid),'cmdline')
 try:return [x.decode() for x in p.read_bytes().split(b'\0') if x]
 except FileNotFoundError:return []
def stamp(pid):
 return Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]
def verified(pid,expected,start=None):
 end=time.monotonic()+2
 while proc_args(pid)!=expected and time.monotonic()<end:time.sleep(.01)
 if proc_args(pid)!=expected:raise RuntimeError('owned PID exact argv mismatch after bounded exec wait')
 s=stamp(pid)
 if start is not None and s!=start:raise RuntimeError('owned PID starttime mismatch')
 return s
def stop(kind,arm):
 pf=pidfile(kind,arm)
 if not pf.exists():return
 pid=int(pf.read_text())
 args=proc_args(pid)
 if not args:pf.unlink();return
 rec=RUN/(pf.name+'.json');data=json.loads(rec.read_text())
 verified(pid,argv(kind,arm),data['starttime'])
 os.kill(pid,signal.SIGTERM)
 end=time.monotonic()+8
 while proc_args(pid) and time.monotonic()<end:time.sleep(.05)
 if proc_args(pid):
  verified(pid,argv(kind,arm),data['starttime']);os.kill(pid,signal.SIGKILL)
  end=time.monotonic()+3
  while proc_args(pid) and time.monotonic()<end:time.sleep(.05)
 if proc_args(pid):raise RuntimeError('owned process failed to stop')
 data['stopped_at']=now();write(unique('stopped-'+kind+'-'+arm).with_suffix('.json'),data)
 pf.unlink()
def spawn(kind,arm):
 a=argv(kind,arm);e=env()
 if kind=='power':e['A3S_POWER_HOME']=str(RUN/(arm+'-home'))
 log=unique(kind+'-'+arm).with_suffix('.log')
 with log.open('ab') as f:p=subprocess.Popen(a,env=e,cwd='/code/Power',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 s=verified(p.pid,a);pf=pidfile(kind,arm);pf.write_text(str(p.pid)+'\n')
 write(RUN/(pf.name+'.json'),{'pid':p.pid,'argv':a,'starttime':s,'log':str(log),'created_at':now(),'A3S_POWER_HOME':e.get('A3S_POWER_HOME')})
 return p.pid
def wait_http(port,path='/health',seconds=15):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   code,value=request('http://127.0.0.1:'+str(port)+path)
   if code==200:return value
  except (OSError,ValueError):pass
  time.sleep(.1)
 raise RuntimeError('readiness deadline on private port '+str(port))
def immutable_config(path,text):
 if path.exists():
  if path.read_text()!=text:raise RuntimeError('existing rig configuration differs; no overwrite')
 else:path.write_text(text);path.chmod(0o600)
def init():
 if sha(ENGINE)!=BASE['runtime_sha256']:raise RuntimeError('pinned runtime SHA mismatch')
 RUN.mkdir(mode=0o700,exist_ok=True);RUN.chmod(0o700)
 key=KEY.read_text().strip()
 if not key or '\n' in key or '\r' in key:raise RuntimeError('benchmark key invalid')
 for arm,pp,gp,n in [('baseline',19400,19884,1),('candidate',19410,19885,4)]:
  for src,dest,digest in [(ROOT/'candidate-power',RUN/(arm+'-power'),POWER_SHA),(ROOT/'gateway-cancel-candidate',RUN/('gateway-'+arm),GW_SHA)]:
   if sha(src)!=digest:raise RuntimeError('pinned binary mismatch')
   if dest.exists():
    if sha(dest)!=digest:raise RuntimeError('rig binary mismatch')
   else:shutil.copy2(src,dest);dest.chmod(0o700)
  text=f'host = "127.0.0.1"\nport = {pp}\ndata_dir = "{RUN/(arm+"-data")}"\nprism_upstream = "http://127.0.0.1:{PORT}"\nprism_profile = "baseline"\ntee_mode = false\nspec_mode = "off"\nnum_parallel = {n}\nmax_concurrent_requests = {n}\nmax_queued_requests = 8\nqueue_timeout_ms = 1000\napi_keys = [{json.dumps(key)}]\n'
  immutable_config(RUN/(arm+'.acl'),text)
  redacted=text.replace(json.dumps(key),'"BENCHMARK_KEY_REDACTED"')
  immutable_config(RUN/(arm+'-redacted.acl'),redacted)
  template=(ROOT/'gateway-candidate.acl').read_text().replace('127.0.0.1:19881','127.0.0.1:'+str(gp)).replace('127.0.0.1:19210','127.0.0.1:'+str(pp))
  # The template uses the same root benchmark key; no credential is copied from production state.
  immutable_config(RUN/('gateway-'+arm+'.acl'),template)
  red=template.replace('Bearer '+key,'Bearer BENCHMARK_KEY_REDACTED')
  immutable_config(RUN/('gateway-'+arm+'-redacted.acl'),red)
  result=subprocess.run([str(RUN/('gateway-'+arm)),'validate','--config',str(RUN/('gateway-'+arm+'.acl'))],capture_output=True,timeout=15)
  log=unique('gateway-'+arm+'-validate').with_suffix('.log');log.write_bytes(result.stdout+result.stderr)
  if result.returncode:raise RuntimeError('gateway validation failed; private log retained')
  prov=dict(BASE);prov.update({'arm':arm,'gpu_indices':[GPU],'slots':n,'context_per_sequence':32768,'runtime_flags':flags(arm),'config_redacted_sha256':sha(RUN/(arm+'-redacted.acl')),'admission':{'active':n,'waiting_limit':8,'queue_timeout_ms':1000},'observed_at_utc':now(),'binary_sha256':POWER_SHA,'profile':'slot-study-rig5'})
  # Initial proposal is updated only by actual readiness; result files remain immutable.
  path=RUN/(arm+'-provenance.json')
  if not path.exists():write(path,prov)
def engine_run(arm):
 attempt=unique('engine-'+arm);pid=None;reason='exited';peak=0;stopping=False
 def interrupted(signum,frame):
  nonlocal stopping
  stopping=True
 signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGHUP,interrupted)
 result={'arm':arm,'created_at':now(),'gpu_index':GPU,'argv':engine_argv(arm),'guard_fraction':LIMIT,'env':{'CUDA_VISIBLE_DEVICES':str(GPU),'GGML_CUDA_DISABLE_GRAPHS':'unset','GGML_CUDA_PTQ1_0_MMQ_MAX_BATCH':'unset'},'attempt':str(attempt)}
 e=env();e['CUDA_VISIBLE_DEVICES']=str(GPU)
 try:
  for port in [PORT]:
   with socket.socket() as s:
    s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',port))
  result['gpu_before']=gpu()
  if result['gpu_before']['used_mib']/result['gpu_before']['total_mib']>LIMIT:raise RuntimeError('preexisting whole GPU memory exceeds guard; no engine started')
  guard_deadline=time.monotonic()+5400
  with attempt.with_suffix('.log').open('ab') as f:p=subprocess.Popen(engine_argv(arm),env=e,cwd=str(ENGINE.parent),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  pid=p.pid;result['spawned_child_pid']=pid;s=verified(pid,engine_argv(arm));(RUN/'engine.pid').write_text(str(pid)+'\n')
  result.update({'pid':pid,'starttime':s,'status':'starting'})
  write(RUN/'engine.pid.json',result);write(RUN/'current-engine.json',result)
  with attempt.with_suffix('.gpu.jsonl').open('w') as telemetry:
   while p.poll() is None:
    obs=gpu();obs['observed_at']=now();peak=max(peak,obs['used_mib']);telemetry.write(json.dumps(obs)+'\n');telemetry.flush()
    if obs['used_mib']/obs['total_mib']>LIMIT:reason='rejected-memory-guard';break
    if time.monotonic()>guard_deadline:reason='guard-lifetime-90min-expired';break
    if stopping:reason='requested-stop';break
    time.sleep(.5)
   if p.poll() is None:
    verified(pid,engine_argv(arm),s);p.terminate()
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:verified(pid,engine_argv(arm),s);p.kill();p.wait(timeout=3)
   result.update({'status':reason,'exit_code':p.returncode,'peak_gpu_used_mib':peak,'finished_at':now()})
 except BaseException as error:
  result.update({'status':'error','error_type':type(error).__name__,'error':str(error)})
 finally:
  if pid is not None and proc_args(pid):
   verified(pid,engine_argv(arm),result['starttime']);os.kill(pid,signal.SIGTERM)
  write(attempt.with_suffix('.json'),result)
  pf=RUN/'engine.pid'
  if pf.exists() and pid is not None and int(pf.read_text())==pid:write(RUN/'current-engine.json',result)
def ensure_engine(arm):
 current=RUN/'engine.pid'
 if current.exists():
  meta=json.loads((RUN/'engine.pid.json').read_text())
  if meta['arm']==arm and proc_args(int(current.read_text()))==engine_argv(arm):
   verified(int(current.read_text()),engine_argv(arm),meta['starttime'])
  else:stop('engine',meta['arm'])
 if not current.exists():
  with unique('engine-supervisor-'+arm).with_suffix('.log').open('ab') as f:p=subprocess.Popen([sys.executable,str(HERE),'engine-run',arm],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  (RUN/'engine-supervisor.pid').write_text(str(p.pid)+'\n')
  end=time.monotonic()+45
  while not current.exists() and time.monotonic()<end:
   if p.poll() is not None:raise RuntimeError('engine supervisor rejected startup')
   time.sleep(.1)
 wait_http(PORT,seconds=45)
 bound_pid=int(current.read_text());bound_meta=json.loads((RUN/'engine.pid.json').read_text())
 verified(bound_pid,engine_argv(arm),bound_meta['starttime'])
 h=request('http://127.0.0.1:'+str(PORT)+'/props')[1]
 slots=request('http://127.0.0.1:'+str(PORT)+'/slots')[1]
 n=1 if arm=='baseline' else 4
 if h.get('total_slots')!=n or h.get('default_generation_settings',{}).get('n_ctx')!=32768:raise RuntimeError('native context/slot geometry mismatch')
 if len(slots)!=n:raise RuntimeError('native /slots count mismatch')
 if any(s.get('n_ctx')!=32768 for s in slots):raise RuntimeError('slot context mismatch')
 obs=gpu()
 if obs['used_mib']/obs['total_mib']>LIMIT:raise RuntimeError('readiness exceeds GPU guard')
 verified(bound_pid,engine_argv(arm),bound_meta['starttime'])
 return {'props':h,'slots':slots,'gpu':obs,'pid':int(current.read_text()),'expected_total_context':n*32768,'observed_context_per_sequence':32768}
def start_arm(arm):
 for kind in ['power','gateway']:
  pf=pidfile(kind,arm)
  if pf.exists():
   p=int(pf.read_text())
   if proc_args(p):verified(p,argv(kind,arm),json.loads((RUN/(pf.name+'.json')).read_text())['starttime'])
   else:pf.unlink()
  if kind=='power':
   if not pf.exists():spawn(kind,arm)
   wait_http(19400 if arm=='baseline' else 19410)
   home=RUN/(arm+'-home');manifest=home/'models/manifests/prism27b.json'
   pid=int(pf.read_text());pe=Path('/proc',str(pid),'environ').read_bytes().split(b'\0')
   if ('A3S_POWER_HOME='+str(home)).encode() not in pe:raise RuntimeError('registry home isolation not effective')
   if not manifest.exists():
    status,_=request('http://127.0.0.1:'+str(19400 if arm=='baseline' else 19410)+'/v1/models',{'name':'prism27b','path':MODEL,'format':'gguf'},True,90)
    if status!=201:raise RuntimeError('registration status mismatch')
   m=json.loads(manifest.read_text())
   if m.get('path')!=MODEL or m.get('sha256')!=BASE['model_sha256']:raise RuntimeError('private target integrity mismatch')
  else:
   if not pf.exists():spawn(kind,arm)
   wait_http(19884 if arm=='baseline' else 19885)
def require_idle():
 pf=RUN/'engine.pid'
 if pf.exists() and proc_args(int(pf.read_text())):
  raw=urllib.request.urlopen('http://127.0.0.1:'+str(PORT)+'/metrics',timeout=3).read(1024*1024).decode()
  m={k:float(v) for line in raw.splitlines() if line and not line.startswith('#') for k,v in [line.rsplit(None,1)]}
  if m.get('llamacpp:requests_processing')!=0 or m.get('llamacpp:requests_deferred')!=0:raise RuntimeError('phase switch refused: native engine is not idle')
 for arm,port in [('baseline',19400),('candidate',19410)]:
  pf=pidfile('power',arm)
  if pf.exists() and proc_args(int(pf.read_text())):
   a=request('http://127.0.0.1:'+str(port)+'/health')[1]['worker']['admission']
   if a['active']!=0 or a['waiting']!=0:raise RuntimeError('phase switch refused: Power active/waiting')
def switch(arm,smoke=False):
 if arm=='candidate' and (RUN/'candidate-capacity-rejection.json').exists():raise RuntimeError('rig5 NP4 capacity-disqualified under coexistence guard; no retry')
 require_idle()
 other='candidate' if arm=='baseline' else 'baseline'
 for kind in ['gateway','power']:stop(kind,other)
 geometry=ensure_engine(arm);start_arm(arm)
 health=request('http://127.0.0.1:'+str(19400 if arm=='baseline' else 19410)+'/health')[1]
 n=1 if arm=='baseline' else 4
 if health['inference']['num_parallel']!=n or health['worker']['admission']['active_limit']!=n:raise RuntimeError('Power admission mismatch')
 result={'arm':arm,'observed_at':now(),'geometry':geometry,'power_health':health,'power_pid':int(pidfile('power',arm).read_text()),'gateway_pid':int(pidfile('gateway',arm).read_text()),'formal_load_run':False}
 if smoke:
  spec=importlib.util.spec_from_file_location('qualification','/code/aster/scripts/power_serving_qualification.py');q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
  body={'model':'prism27b','messages':[{'role':'user','content':'Reply with exactly OK.'}],'max_tokens':16,'temperature':0,'seed':42,'stream':False}
  result['smoke']=q.request_once('http://127.0.0.1:'+str(19884 if arm=='baseline' else 19885)+'/v1',body,KEY.read_text().strip(),15,expected={'text':'OK','normalize_whitespace':True})
  if result['smoke']['outcome']!='success':raise RuntimeError('finite smoke expected OK failed')
 result['slots_after']=request('http://127.0.0.1:'+str(PORT)+'/slots')[1]
 p=RUN/(arm+'-provenance.json');prov=json.loads(p.read_text());prov['observed_at_utc']=now();write(p,prov)
 write(unique('readiness-'+arm).with_suffix('.json'),result);write(RUN/'current-phase.json',result)
 return result
def setup():
 init();result={'started_at':now(),'phases':{},'formal_load_run':False,'phase_order_for_later_formal':[['baseline','candidate'],['candidate','baseline'],['baseline','candidate']]}
 try:
  result['phases']['baseline']=switch('baseline',True)
  try:result['phases']['candidate']=switch('candidate',True);result['np4_qualified_geometry']=True
  except BaseException as error:result['np4_qualified_geometry']=False;result['np4_rejection']={'type':type(error).__name__,'reason':str(error),'engine_state':json.loads((RUN/'current-engine.json').read_text())}
 finally:
  result['final_baseline']=switch('baseline',True);result['finished_at']=now();result['gpu_final']=gpu()
  write(unique('setup-result').with_suffix('.json'),result);write(RUN/'setup-latest.json',result)
 print(json.dumps({'np4_qualified_geometry':result.get('np4_qualified_geometry'),'baseline_ready':True,'final_gpu':result['gpu_final'],'candidate_power_running':pidfile('power','candidate').exists()}))
if __name__=='__main__':
 action=sys.argv[1] if len(sys.argv)>1 else ''
 if action in ['init','setup','switch','stop']:
  RUN.mkdir(mode=0o700,exist_ok=True);lock=(RUN/'phase.lock').open('a')
  fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
 if action=='engine-run':engine_run(sys.argv[2])
 elif action=='init':init()
 elif action=='setup':setup()
 elif action=='switch':print(json.dumps({'arm':sys.argv[2],'ready':bool(switch(sys.argv[2],'--smoke' in sys.argv[3:]))}))
 elif action=='status':print((RUN/'current-phase.json').read_text())
 elif action=='stop':
  require_idle()
  for arm in ['baseline','candidate']:
   for kind in ['gateway','power']:stop(kind,arm)
  if (RUN/'engine.pid').exists():stop('engine',json.loads((RUN/'engine.pid.json').read_text())['arm'])
 else:raise SystemExit('usage: supervisor.py init|setup|switch baseline|candidate [--smoke]|status')
