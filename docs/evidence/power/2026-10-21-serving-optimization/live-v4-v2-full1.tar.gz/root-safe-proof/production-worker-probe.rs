//! Closed per-worker production recovery/warmup probe. Execution requires root.
//! Credentials are parsed inside an anonymous sealed memfd and never persisted.
//! This binary changes no configuration, units, models, registry or credentials.
use a3s_power::config::PowerConfig;
use a3s_power::server::auth::{ApiKeyAuth, AuthProvider};
use serde_json::{json, Value};
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
use std::path::Path;
use std::process::Command;
use std::time::{Duration, Instant};

const ALIAS: &str = "prism-27b";
const LIMIT: usize = 1024 * 1024;
const OLD_POWER_SHA: &str = "29d239e2495400036af24c7b1bca248e397bbb15b5c13646533d519fb2f345af";
const NATIVE_SHA: &str = "661b413b780759bfa2c9b8fd87608c15fcc3651142d771b1c94d11d01195d298";
const CANDIDATE_POWER_SHA: &str =
    "75afe5de8d423547fdb9b9bb302b17ca9e168d6f6fe13a18d29fbce9492bf1c1";
type SafeResult<T> = Result<T, &'static str>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Artifact {
    Baseline,
    Candidate,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Selection {
    gpu: u8,
    artifact: Artifact,
}

impl Selection {
    fn acl(self) -> String {
        format!("/etc/a3s/power/{}.acl", self.gpu)
    }
    fn base(self) -> String {
        format!("http://127.0.0.1:{}", self.port())
    }
    fn port(self) -> u16 {
        18200 + u16::from(self.gpu)
    }
    fn power_unit(self) -> String {
        format!("a3s-power@{}.service", self.gpu)
    }
    fn native_unit(self) -> String {
        format!("prism-27b@{}.service", self.gpu)
    }
    fn expected_sha(self) -> &'static str {
        match self.artifact {
            Artifact::Baseline => OLD_POWER_SHA,
            Artifact::Candidate => CANDIDATE_POWER_SHA,
        }
    }
    fn expected_path(self) -> String {
        match self.artifact {
            Artifact::Baseline => "/opt/a3s/bin/a3s-power".to_string(),
            Artifact::Candidate => format!("/opt/a3s/releases/{}/a3s-power", CANDIDATE_POWER_SHA),
        }
    }
    fn artifact_name(self) -> &'static str {
        match self.artifact {
            Artifact::Baseline => "baseline",
            Artifact::Candidate => "candidate",
        }
    }
}

fn parse_selection(args: &[String]) -> SafeResult<Selection> {
    if args.len() != 4 || args[0] != "--gpu" || args[2] != "--artifact" {
        return Err("closed-worker-selection-required");
    }
    let gpu = match args[1].as_bytes() {
        [value @ b'0'..=b'7'] => value - b'0',
        _ => return Err("closed-gpu-index-required"),
    };
    let artifact = match args[3].as_str() {
        "baseline" => Artifact::Baseline,
        "candidate" => Artifact::Candidate,
        _ => return Err("closed-artifact-required"),
    };
    Ok(Selection { gpu, artifact })
}

unsafe extern "C" {
    fn geteuid() -> u32;
    fn memfd_create(name: *const std::ffi::c_char, flags: u32) -> i32;
    fn fcntl(fd: i32, command: i32, ...) -> i32;
}

fn approved_metadata(
    regular: bool,
    symlink: bool,
    uid: u32,
    gid: u32,
    mode: u32,
    len: u64,
) -> bool {
    regular
        && !symlink
        && uid == 1000
        && gid == 1000
        && mode & 0o7777 == 0o600
        && len > 0
        && len <= LIMIT as u64
}

fn choose_raw_key(config: &PowerConfig) -> SafeResult<String> {
    let auth = ApiKeyAuth::new(&config.api_keys);
    // Reuse the exact existing authentication contract; stored hashes are not
    // usable Bearer credentials and must never be guessed or sent as tokens.
    config
        .api_keys
        .iter()
        .find(|key| !key.trim().is_empty() && auth.authenticate(key))
        .cloned()
        .ok_or("no-recoverable-raw-key")
}

fn load_local_key(path: &Path) -> SafeResult<String> {
    let before = fs::symlink_metadata(path).map_err(|_| "config-metadata")?;
    if !approved_metadata(
        before.is_file(),
        before.file_type().is_symlink(),
        before.uid(),
        before.gid(),
        before.mode(),
        before.len(),
    ) {
        return Err("config-metadata-refused");
    }
    let mut original = OpenOptions::new()
        .read(true)
        .custom_flags(0x20000)
        .open(path)
        .map_err(|_| "config-open")?; // Linux O_NOFOLLOW.
    let opened = original.metadata().map_err(|_| "config-opened-metadata")?;
    if opened.dev() != before.dev() || opened.ino() != before.ino() {
        return Err("config-generation-changed");
    }
    let mut bytes = Vec::new();
    (&mut original)
        .take((LIMIT + 1) as u64)
        .read_to_end(&mut bytes)
        .map_err(|_| "config-bounded-read")?;
    if bytes.is_empty() || bytes.len() > LIMIT {
        return Err("config-byte-bound");
    }
    let after = original.metadata().map_err(|_| "config-after-metadata")?;
    if opened.len() != after.len()
        || opened.mtime_nsec() != after.mtime_nsec()
        || opened.mtime() != after.mtime()
        || opened.ctime_nsec() != after.ctime_nsec()
        || opened.ctime() != after.ctime()
    {
        return Err("config-generation-changed");
    }
    let input = std::str::from_utf8(&bytes).map_err(|_| "config-utf8")?;
    a3s_acl::parse(input).map_err(|_| "config-acl-parse")?;
    let descriptor = unsafe { memfd_create(c"power-recovery-config".as_ptr(), 3) };
    if descriptor < 0 {
        return Err("anonymous-config-fd");
    }
    let mut memory = unsafe { File::from_raw_fd(descriptor) };
    memory
        .write_all(&bytes)
        .map_err(|_| "anonymous-config-write")?;
    bytes.fill(0);
    // F_ADD_SEALS with SEAL_SEAL|SHRINK|GROW|WRITE; never a disk credential copy.
    if unsafe { fcntl(memory.as_raw_fd(), 1033, 15) } != 0 {
        return Err("anonymous-config-seal");
    }
    let fd_path = format!("/proc/self/fd/{}", memory.as_raw_fd());
    let config = PowerConfig::load_from(&fd_path).map_err(|_| "typed-config-validation")?;
    match choose_raw_key(&config) {
        Ok(key) => Ok(key),
        Err(_) => gateway_configured_key(&config),
    }
}

fn gateway_token_from_environment(bytes: &[u8], config: &PowerConfig) -> SafeResult<String> {
    const NAME: &[u8] = b"A3S_GATEWAY_SHARED_TOKEN=";
    let found: Vec<&[u8]> = bytes
        .split(|byte| *byte == 0)
        .filter_map(|entry| entry.strip_prefix(NAME))
        .collect();
    if found.len() != 1 {
        return Err("gateway-configured-token-unavailable");
    }
    let candidate =
        std::str::from_utf8(found[0]).map_err(|_| "gateway-configured-token-encoding")?;
    if candidate.is_empty() || !ApiKeyAuth::new(&config.api_keys).authenticate(candidate) {
        return Err("gateway-configured-token-does-not-match-power");
    }
    Ok(candidate.to_string())
}

fn gateway_configured_key(config: &PowerConfig) -> SafeResult<String> {
    // Only this exact, already configured client credential is permitted.
    // Never inspect the Gateway ACL, credential dropin or environment files.
    let output = Command::new("systemctl")
        .args(["show", "a3s-gateway.service", "-p", "MainPID", "--value"])
        .output()
        .map_err(|_| "gateway-pid-query")?;
    if !output.status.success() || output.stdout.len() > 32 {
        return Err("gateway-pid-query");
    }
    let pid: u32 = std::str::from_utf8(&output.stdout)
        .map_err(|_| "gateway-pid")?
        .trim()
        .parse()
        .map_err(|_| "gateway-pid")?;
    if pid == 0 {
        return Err("gateway-not-running");
    }
    let mut file =
        File::open(format!("/proc/{pid}/environ")).map_err(|_| "gateway-environment-open")?;
    let mut bytes = Vec::new();
    (&mut file)
        .take((LIMIT + 1) as u64)
        .read_to_end(&mut bytes)
        .map_err(|_| "gateway-environment-read")?;
    if bytes.len() > LIMIT {
        bytes.fill(0);
        return Err("gateway-environment-byte-bound");
    }
    let result = gateway_token_from_environment(&bytes, config);
    bytes.fill(0);
    result
}

fn trusted_parents() -> SafeResult<()> {
    for path in ["/etc", "/etc/a3s", "/etc/a3s/power"] {
        let info = fs::symlink_metadata(path).map_err(|_| "config-parent-metadata")?;
        if !info.is_dir()
            || info.file_type().is_symlink()
            || info.uid() != 0
            || info.mode() & 0o022 != 0
        {
            return Err("config-parent-untrusted");
        }
    }
    Ok(())
}

fn process_identity(unit: &str, expected_path: &str, expected_sha: &str) -> SafeResult<Value> {
    let output = Command::new("systemctl")
        .args(["show", unit, "-p", "MainPID", "--value"])
        .output()
        .map_err(|_| "process-unit-query")?;
    if !output.status.success() || output.stdout.len() > 32 {
        return Err("process-unit-query");
    }
    let pid: u32 = std::str::from_utf8(&output.stdout)
        .map_err(|_| "process-pid")?
        .trim()
        .parse()
        .map_err(|_| "process-pid")?;
    if pid == 0 {
        return Err("process-not-running");
    }
    let root = format!("/proc/{pid}");
    let exe = fs::read_link(format!("{root}/exe")).map_err(|_| "process-exe")?;
    let sha = a3s_power::model::storage::compute_sha256_path(Path::new(&format!("{root}/exe")))
        .map_err(|_| "process-exe-hash")?;
    if exe != Path::new(expected_path) || sha != expected_sha {
        return Err("rollback-executable-mismatch");
    }
    let stat = fs::read_to_string(format!("{root}/stat")).map_err(|_| "process-generation")?;
    let start_ticks: u64 = stat
        .rsplit_once(')')
        .ok_or("process-generation")?
        .1
        .split_whitespace()
        .nth(19)
        .ok_or("process-generation")?
        .parse()
        .map_err(|_| "process-generation")?;
    Ok(json!({"pid":pid,"start_ticks":start_ticks,"exe_sha256":sha}))
}

fn require_listener(pid: u64, port: u16) -> SafeResult<()> {
    let mut inodes = Vec::new();
    for table in ["/proc/net/tcp", "/proc/net/tcp6"] {
        let content = fs::read_to_string(table).map_err(|_| "listener-table")?;
        if content.len() > LIMIT {
            return Err("listener-table-bound");
        }
        for line in content.lines().skip(1) {
            let fields: Vec<&str> = line.split_whitespace().collect();
            if fields.len() < 10 || fields[3] != "0A" {
                continue;
            }
            let hex = fields[1].rsplit_once(':').ok_or("listener-address")?.1;
            if u16::from_str_radix(hex, 16).map_err(|_| "listener-port")? == port {
                inodes.push(format!("socket:[{}]", fields[9]));
            }
        }
    }
    if inodes.is_empty() {
        return Err("selected-listener-absent");
    }
    let mut owned = Vec::new();
    for item in fs::read_dir(format!("/proc/{pid}/fd")).map_err(|_| "listener-descriptors")? {
        let path = item.map_err(|_| "listener-descriptor")?.path();
        match fs::read_link(path) {
            Ok(value) => owned.push(value.to_string_lossy().into_owned()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(_) => return Err("listener-descriptor"),
        }
    }
    if !inodes.iter().all(|inode| owned.contains(inode)) {
        return Err("selected-listener-owner");
    }
    Ok(())
}

async fn bounded_json(mut response: reqwest::Response) -> SafeResult<Value> {
    if response.content_length().is_some_and(|n| n > LIMIT as u64) {
        return Err("response-byte-bound");
    }
    let mut bytes = Vec::new();
    while let Some(chunk) = response.chunk().await.map_err(|_| "response-read")? {
        if bytes.len().saturating_add(chunk.len()) > LIMIT {
            return Err("response-byte-bound");
        }
        bytes.extend_from_slice(&chunk);
    }
    serde_json::from_slice(&bytes).map_err(|_| "response-json")
}

async fn one_recovery(base: &str, key: &str, report: &mut Value) -> SafeResult<()> {
    let client = reqwest::Client::builder()
        .no_proxy()
        .redirect(reqwest::redirect::Policy::none())
        .connect_timeout(Duration::from_secs(2))
        .timeout(Duration::from_secs(13))
        .build()
        .map_err(|_| "http-client")?;
    let response = client
        .get(format!("{base}/v1/models"))
        .bearer_auth(key)
        .send()
        .await
        .map_err(|_| "models-transport")?;
    report["models_http_status"] = json!(response.status().as_u16());
    if response.status().as_u16() != 200 {
        return Err("models-not200");
    }
    let models = bounded_json(response).await?;
    let found = models
        .get("data")
        .and_then(Value::as_array)
        .is_some_and(|rows| {
            rows.iter()
                .any(|row| row.get("id").and_then(Value::as_str) == Some(ALIAS))
        });
    report["exact_alias_present"] = json!(found);
    if !found {
        return Err("exact-alias-absent");
    }
    report["completion_requested"] = json!(true);
    let started = Instant::now();
    let response = client
        .post(format!("{base}/v1/chat/completions"))
        .bearer_auth(key)
        .header("Content-Type", "application/json")
        .body(
            json!({"model":ALIAS,"messages":[{"role":"user","content":"Reply with exactly OK."}],
                     "max_tokens":8,"temperature":0,"stream":false})
            .to_string(),
        )
        .send()
        .await
        .map_err(|_| "completion-transport")?;
    report["completion_http_status"] = json!(response.status().as_u16());
    if response.status().as_u16() != 200 {
        return Err("completion-not200");
    }
    let body = bounded_json(response).await?;
    let expected = body
        .pointer("/choices/0/message/content")
        .and_then(Value::as_str)
        .is_some_and(|value| value.trim() == "OK");
    report["expected_output"] = json!(expected);
    report["completion_wall_seconds"] = json!(started.elapsed().as_secs_f64());
    if !expected {
        return Err("unexpected-synthetic-response");
    }
    Ok(())
}

async fn checked_worker_recovery(
    base: &str,
    key: &str,
    observed_power_sha: &str,
    expected_power_sha: &str,
    report: &mut Value,
) -> SafeResult<()> {
    if observed_power_sha != expected_power_sha {
        return Err("worker-executable-mismatch-before-http");
    }
    one_recovery(base, key, report).await?;
    let client = reqwest::Client::builder()
        .no_proxy()
        .redirect(reqwest::redirect::Policy::none())
        .connect_timeout(Duration::from_secs(2))
        .timeout(Duration::from_secs(13))
        .build()
        .map_err(|_| "health-http-client")?;
    let response = client
        .get(format!("{base}/health"))
        .bearer_auth(key)
        .send()
        .await
        .map_err(|_| "health-transport")?;
    report["health_http_status"] = json!(response.status().as_u16());
    if response.status().as_u16() != 200 {
        return Err("health-not200");
    }
    let body = bounded_json(response).await?;
    let loaded = body.get("status").and_then(Value::as_str) == Some("ok")
        && body
            .get("loaded_models")
            .and_then(Value::as_u64)
            .is_some_and(|count| count >= 1);
    report["actual_production_worker_loaded"] = json!(loaded);
    if !loaded {
        return Err("actual-production-worker-not-loaded");
    }
    Ok(())
}

fn main() {
    let started = Instant::now();
    if unsafe { geteuid() } != 0 {
        println!("{}", json!({"status":"refused","reason":"root-only"}));
        std::process::exit(1);
    }
    let args: Option<Vec<String>> = std::env::args_os()
        .skip(1)
        .map(|value| value.into_string().ok())
        .collect();
    let selected = match args
        .as_deref()
        .ok_or("closed-worker-selection-required")
        .and_then(parse_selection)
    {
        Ok(value) => value,
        Err(reason) => {
            println!("{}", json!({"status":"refused","reason":reason}));
            std::process::exit(1);
        }
    };
    std::thread::spawn(|| {
        std::thread::sleep(Duration::from_secs(15));
        println!(
            "{}",
            json!({"status":"deadline-exceeded","absolute_seconds":15})
        );
        std::process::exit(2);
    });
    let mut report = json!({"status":"refused","gpu":selected.gpu,"artifact":selected.artifact_name(),
        "credentials_output":false,"completion_requested":false,"expected_output":false,
        "actual_production_worker_loaded":false});
    let result: SafeResult<()> = (|| {
        if std::env::vars_os().any(|(name, _)| name.to_string_lossy().starts_with("A3S_POWER_")) {
            return Err("power-environment-override-present");
        }
        trusted_parents()?;
        let key = load_local_key(Path::new(&selected.acl()))?;
        let power = process_identity(
            &selected.power_unit(),
            &selected.expected_path(),
            selected.expected_sha(),
        )?;
        let native = process_identity(
            &selected.native_unit(),
            "/data/prism/llama-prism-b10787-73bfe6c/llama-server",
            NATIVE_SHA,
        )?;
        require_listener(power["pid"].as_u64().ok_or("process-pid")?, selected.port())?;
        report["power"] = power.clone();
        report["native"] = native.clone();
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|_| "async-runtime")?;
        let remaining = Duration::from_secs(14)
            .checked_sub(started.elapsed())
            .ok_or("absolute-deadline")?;
        let base = selected.base();
        runtime.block_on(async {
            tokio::time::timeout(
                remaining,
                checked_worker_recovery(
                    &base,
                    &key,
                    power["exe_sha256"].as_str().ok_or("process-exe-hash")?,
                    selected.expected_sha(),
                    &mut report,
                ),
            )
            .await
            .map_err(|_| "absolute-deadline")?
        })?;
        if process_identity(
            &selected.power_unit(),
            &selected.expected_path(),
            selected.expected_sha(),
        )? != power
            || process_identity(
                &selected.native_unit(),
                "/data/prism/llama-prism-b10787-73bfe6c/llama-server",
                NATIVE_SHA,
            )? != native
        {
            return Err("generation-changed-during-probe");
        }
        require_listener(power["pid"].as_u64().ok_or("process-pid")?, selected.port())?;
        Ok(())
    })();
    report["wall_seconds"] = json!(started.elapsed().as_secs_f64());
    match result {
        Ok(()) => report["status"] = json!("worker-recovery-passed"),
        Err(reason) => report["reason"] = json!(reason),
    }
    println!("{report}");
    std::process::exit(if result.is_ok() { 0 } else { 1 });
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{TcpListener, TcpStream};
    use std::sync::{Arc, Mutex};
    use std::thread;

    fn request(stream: &mut TcpStream) -> (String, Value) {
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let mut bytes = Vec::new();
        let end = loop {
            let mut byte = [0];
            stream.read_exact(&mut byte).unwrap();
            bytes.push(byte[0]);
            assert!(bytes.len() < 16384);
            if bytes.ends_with(b"\r\n\r\n") {
                break bytes.len();
            }
        };
        let headers = String::from_utf8(bytes).unwrap();
        assert!(headers
            .to_ascii_lowercase()
            .contains("authorization: bearer fixture-token"));
        let len = headers
            .lines()
            .find_map(|line| {
                line.split_once(':')
                    .filter(|(name, _)| name.eq_ignore_ascii_case("content-length"))
                    .map(|(_, value)| value.trim().parse::<usize>().unwrap())
            })
            .unwrap_or(0);
        assert!(len < 8192);
        let mut body = vec![0; len];
        stream.read_exact(&mut body).unwrap();
        let _ = end;
        (
            headers.lines().next().unwrap().to_string(),
            if body.is_empty() {
                Value::Null
            } else {
                serde_json::from_slice(&body).unwrap()
            },
        )
    }

    fn fixture(
        status: u16,
        alias: &str,
        pause: Duration,
    ) -> (String, Arc<Mutex<Vec<Value>>>, thread::JoinHandle<()>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let base = format!("http://{}", listener.local_addr().unwrap());
        let captures = Arc::new(Mutex::new(Vec::new()));
        let observed = captures.clone();
        let alias = alias.to_string();
        let handle = thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let (line, body) = request(&mut stream);
            assert_eq!(line, "GET /v1/models HTTP/1.1");
            observed.lock().unwrap().push(body);
            thread::sleep(pause);
            let raw = json!({"data":[{"id":alias}]}).to_string();
            let response = format!("HTTP/1.1 {status} fixture\r\nContent-Type: application/json\r\nConnection: close\r\nContent-Length: {}\r\n\r\n{raw}", raw.len());
            if stream.write_all(response.as_bytes()).is_err() {
                return;
            }
            if status != 200 || alias != ALIAS || !pause.is_zero() {
                return;
            }
            let (mut stream, _) = listener.accept().unwrap();
            let (line, body) = request(&mut stream);
            assert_eq!(line, "POST /v1/chat/completions HTTP/1.1");
            observed.lock().unwrap().push(body);
            let raw = r#"{"choices":[{"message":{"content":"OK"},"finish_reason":"stop"}]}"#;
            write!(stream, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\nContent-Length: {}\r\n\r\n{}", raw.len(), raw).unwrap();
        });
        (base, captures, handle)
    }

    fn run(base: &str, seconds: Duration) -> (SafeResult<()>, Value) {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let mut report = json!({"completion_requested":false});
        let result = runtime.block_on(async {
            tokio::time::timeout(seconds, one_recovery(base, "fixture-token", &mut report))
                .await
                .map_err(|_| "absolute-deadline")?
        });
        (result, report)
    }

    #[test]
    fn raw_key_selection_uses_existing_auth_contract() {
        let mut config = PowerConfig::default();
        config.api_keys = vec!["a".repeat(64)];
        assert_eq!(choose_raw_key(&config), Err("no-recoverable-raw-key"));
        config.api_keys.push("fixture-token".into());
        assert_eq!(choose_raw_key(&config).unwrap(), "fixture-token");
    }

    #[test]
    fn configured_gateway_token_requires_exact_local_power_auth_match() {
        let mut config = PowerConfig::default();
        config.api_keys = vec![a3s_power::model::storage::compute_sha256(b"fixture-token")];
        assert_eq!(
            gateway_token_from_environment(
                b"OTHER=not-used\0A3S_GATEWAY_SHARED_TOKEN=fixture-token\0",
                &config
            )
            .unwrap(),
            "fixture-token"
        );
        assert_eq!(
            gateway_token_from_environment(b"A3S_GATEWAY_SHARED_TOKEN=wrong\0", &config),
            Err("gateway-configured-token-does-not-match-power")
        );
        assert_eq!(
            gateway_token_from_environment(
                b"A3S_GATEWAY_SHARED_TOKEN=fixture-token\0A3S_GATEWAY_SHARED_TOKEN=fixture-token\0",
                &config
            ),
            Err("gateway-configured-token-unavailable")
        );
        assert_eq!(
            gateway_token_from_environment(
                b"NOT_A3S_GATEWAY_SHARED_TOKEN=fixture-token\0",
                &config
            ),
            Err("gateway-configured-token-unavailable")
        );
    }

    #[test]
    fn metadata_is_closed_to_verified_service_tuple() {
        assert!(approved_metadata(true, false, 1000, 1000, 0o600, 227));
        for args in [
            (true, false, 0, 0, 0o600, 227),
            (true, false, 1000, 1000, 0o644, 227),
            (true, true, 1000, 1000, 0o600, 227),
            (false, false, 1000, 1000, 0o600, 227),
            (true, false, 1000, 1000, 0o600, 0),
            (true, false, 1000, 1000, 0o600, LIMIT as u64 + 1),
        ] {
            assert!(!approved_metadata(
                args.0, args.1, args.2, args.3, args.4, args.5
            ));
        }
    }

    #[test]
    fn typed_acl_parser_works_only_in_anonymous_memory() {
        let path =
            std::env::temp_dir().join(format!("power-recovery-fixture-{}", std::process::id()));
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&path)
            .unwrap();
        file.write_all(b"api_keys = [\"fixture-token\"]\n").unwrap();
        file.flush().unwrap();
        assert_eq!(load_local_key(&path).unwrap(), "fixture-token");
        fs::remove_file(path).unwrap();
    }

    #[test]
    fn actual_loopback_auth_models_then_exact_one_completion() {
        let (base, captured, handle) = fixture(200, ALIAS, Duration::ZERO);
        let (result, report) = run(&base, Duration::from_secs(2));
        result.unwrap();
        handle.join().unwrap();
        let data = captured.lock().unwrap();
        assert_eq!(data.len(), 2);
        assert_eq!(
            data[1],
            json!({"model":ALIAS,"messages":[{"role":"user","content":"Reply with exactly OK."}],
                                 "max_tokens":8,"temperature":0,"stream":false})
        );
        assert_eq!(report["expected_output"], true);
        assert!(!report.to_string().contains("fixture-token"));
    }

    #[test]
    fn auth_refusal_sends_no_completion_and_never_falls_back() {
        let (base, captured, handle) = fixture(401, ALIAS, Duration::ZERO);
        let (result, report) = run(&base, Duration::from_secs(2));
        assert_eq!(result, Err("models-not200"));
        handle.join().unwrap();
        assert_eq!(captured.lock().unwrap().len(), 1);
        assert_eq!(report["completion_requested"], false);
    }

    #[test]
    fn alias_must_match_exactly_before_completion() {
        let (base, captured, handle) = fixture(200, "prism27b", Duration::ZERO);
        let (result, report) = run(&base, Duration::from_secs(2));
        assert_eq!(result, Err("exact-alias-absent"));
        handle.join().unwrap();
        assert_eq!(captured.lock().unwrap().len(), 1);
        assert_eq!(report["completion_requested"], false);
    }

    #[test]
    fn total_timeout_cancels_slow_response_header_without_post() {
        let (base, captured, handle) = fixture(200, ALIAS, Duration::from_millis(250));
        let begin = Instant::now();
        let (result, report) = run(&base, Duration::from_millis(60));
        assert_eq!(result, Err("absolute-deadline"));
        assert!(begin.elapsed() < Duration::from_millis(200));
        assert_eq!(report["completion_requested"], false);
        handle.join().unwrap();
        assert_eq!(captured.lock().unwrap().len(), 1);
    }

    #[test]
    fn closed_cli_pins_exact_eight_workers_and_two_artifacts() {
        for gpu in 0..8 {
            for artifact in ["baseline", "candidate"] {
                let selection = parse_selection(&[
                    "--gpu".into(),
                    gpu.to_string(),
                    "--artifact".into(),
                    artifact.into(),
                ])
                .unwrap();
                assert_eq!(selection.port(), 18200 + gpu as u16);
                assert_eq!(selection.acl(), format!("/etc/a3s/power/{gpu}.acl"));
                assert_eq!(selection.power_unit(), format!("a3s-power@{gpu}.service"));
                assert_eq!(selection.native_unit(), format!("prism-27b@{gpu}.service"));
                assert_eq!(selection.artifact_name(), artifact);
                assert!(selection.base().starts_with("http://127.0.0.1:1820"));
            }
        }
        for gpu in ["8", "-1", "00", "+1", "7x", "", " 1"] {
            assert!(parse_selection(&[
                "--gpu".into(),
                gpu.into(),
                "--artifact".into(),
                "baseline".into()
            ])
            .is_err());
        }
        for args in [
            vec![],
            vec!["--url", "http://external", "--artifact", "candidate"],
            vec!["--gpu", "0", "--artifact", "other"],
            vec!["--gpu", "0", "--gpu", "0"],
            vec![
                "--gpu",
                "0",
                "--artifact",
                "candidate",
                "--config",
                "/other",
            ],
        ] {
            assert!(
                parse_selection(&args.into_iter().map(str::to_string).collect::<Vec<_>>()).is_err()
            );
        }
    }

    #[test]
    fn wrong_selected_artifact_has_zero_http_connections_and_no_post() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        listener.set_nonblocking(true).unwrap();
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let mut report = json!({"completion_requested":false});
        let result = runtime.block_on(checked_worker_recovery(
            &format!("http://{}", listener.local_addr().unwrap()),
            "fixture-token",
            OLD_POWER_SHA,
            CANDIDATE_POWER_SHA,
            &mut report,
        ));
        assert_eq!(result, Err("worker-executable-mismatch-before-http"));
        assert_eq!(
            listener.accept().unwrap_err().kind(),
            std::io::ErrorKind::WouldBlock
        );
        assert_eq!(report["completion_requested"], false);
    }

    fn worker_fixture(loaded: u64) -> (String, Arc<Mutex<Vec<String>>>, thread::JoinHandle<()>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let base = format!("http://{}", listener.local_addr().unwrap());
        let captures = Arc::new(Mutex::new(Vec::new()));
        let observed = captures.clone();
        let handle = thread::spawn(move || {
            for expected in [
                "GET /v1/models HTTP/1.1",
                "POST /v1/chat/completions HTTP/1.1",
                "GET /health HTTP/1.1",
            ] {
                let (mut stream, _) = listener.accept().unwrap();
                let (line, body) = request(&mut stream);
                assert_eq!(line, expected);
                observed.lock().unwrap().push(line);
                let raw = if expected.starts_with("GET /v1/models ") {
                    json!({"data":[{"id":ALIAS}]}).to_string()
                } else if expected.starts_with("POST ") {
                    assert_eq!(body["model"], ALIAS);
                    assert_eq!(body["max_tokens"], 8);
                    json!({"choices":[{"message":{"content":"OK"},"finish_reason":"stop"}]})
                        .to_string()
                } else {
                    json!({"status":"ok","loaded_models":loaded}).to_string()
                };
                write!(stream, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\nContent-Length: {}\r\n\r\n{}", raw.len(), raw).unwrap();
            }
        });
        (base, captures, handle)
    }

    #[test]
    fn positive_warmup_requires_actual_selected_worker_loaded() {
        for loaded in [0, 1] {
            let (base, captures, handle) = worker_fixture(loaded);
            let runtime = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();
            let mut report = json!({"completion_requested":false});
            let result = runtime.block_on(async {
                tokio::time::timeout(
                    Duration::from_secs(2),
                    checked_worker_recovery(
                        &base,
                        "fixture-token",
                        CANDIDATE_POWER_SHA,
                        CANDIDATE_POWER_SHA,
                        &mut report,
                    ),
                )
                .await
                .unwrap()
            });
            handle.join().unwrap();
            assert_eq!(result.is_ok(), loaded >= 1);
            assert_eq!(report["actual_production_worker_loaded"], loaded >= 1);
            assert_eq!(
                captures
                    .lock()
                    .unwrap()
                    .iter()
                    .filter(|line| line.starts_with("POST "))
                    .count(),
                1
            );
            assert_eq!(captures.lock().unwrap().len(), 3);
            assert!(!report.to_string().contains("fixture-token"));
        }
    }
}
