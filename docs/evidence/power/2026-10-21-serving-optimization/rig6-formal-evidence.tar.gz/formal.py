#!/usr/bin/env python3
"""Finite rig6 NP1/NP2 phase study. Never retries a failed phase."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,time,urllib.request,uuid
ROOT=Path('/code/Power/.git/optimization-20261021');RUN=ROOT/'rig6'
MATRIX=Path('/code/aster/docs/evidence/power/2026-10-21-serving-optimization/matrix-campaign.py')
RUNNER=Path('/code/aster/scripts/power_serving_qualification.py');TESTS=Path('/code/aster/tests/power_serving_qualification.py')
EXPECTED={'runner':'576b2d13811482024522e790f901647ac79dc6cc4368a2622a71adef856fe546','matrix':'b1e24fd648da9b7ae31cb3d3ace44c4b9b91dc6c793a0d9de7ac114ba1b821e4','tests':'f5393cf94090029de17bafc60a3f0248845f073d6a13b641bbd3529a05d77f1c'}
START=time.monotonic();END=START+5400
TAG='formal-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]
OUT=RUN/TAG;OUT.mkdir(mode=0o700)
STATE={'schema':'a3s.power.slot-study-driver.v1','rig':6,'tag':TAG,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'preflight','overall_limit_seconds':5400,'request_deadline_seconds':120,'cleanup_seconds':15,'phase_seconds_per_concurrency':60,'concurrencies':[1,8,16,32],'order':[['baseline','candidate'],['candidate','baseline'],['baseline','candidate']],'factors':['slots','runtime_flags','admission'],'phases':[]}
(RUN/'formal-current.json').write_text(json.dumps({'directory':str(OUT),'tag':TAG,'driver_pid':os.getpid()})+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 temp=path.with_name(path.name+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');os.replace(temp,path)
def save():write(OUT/'driver.json',STATE)
def read_url(url):
 with urllib.request.urlopen(url,timeout=5) as response:
  value=response.read(2*1024*1024)
  if len(value)>=2*1024*1024:raise RuntimeError('observation byte bound')
  return value.decode()
def counters():
 return {k:float(v) for line in read_url('http://127.0.0.1:19110/metrics').splitlines() if line and not line.startswith('#') for k,v in [line.rsplit(None,1)]}
def idle():
 value=counters()
 if value['llamacpp:requests_processing']!=0 or value['llamacpp:requests_deferred']!=0:raise RuntimeError('native not idle')
 return value
def power_snapshot(arm,label):
 port=19300 if arm=='baseline' else 19310
 health=json.loads(read_url(f'http://127.0.0.1:{port}/health'))
 admission=health['worker']['admission']
 if admission['active']!=0 or admission['waiting']!=0:raise RuntimeError('Power not drained')
 lines=[line for line in read_url(f'http://127.0.0.1:{port}/metrics').splitlines() if line.startswith(('power_http_admission_','power_active_requests ','power_requests_waiting ','power_requests_running '))]
 value={'observed_at':now(),'arm':arm,'health_worker':health['worker'],'admission':admission,'metrics':lines}
 write(OUT/(label+'-power-metrics.json'),value);return value

def bounded(command,log,seconds):
 remaining=END-time.monotonic()
 if remaining<=0:raise TimeoutError('overall90min budget exhausted')
 with log.open('w') as output:
  process=subprocess.Popen(command,cwd='/code/aster',stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=min(seconds,remaining))
  except subprocess.TimeoutExpired:
   process.terminate()
   try:process.wait(timeout=15)
   except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
   raise TimeoutError('bounded child deadline; no retry')
 if code:raise RuntimeError('child failed exit '+str(code)+'; '+str(log))

def valid_usage(row):
 usage=row.get('usage')
 if not row.get('usage_source','').startswith('upstream-') or usage is None:raise RuntimeError('success lacks authoritative upstream usage')
 if any(type(usage[k]) is not int or not 0<=usage[k]<=2**64-1 for k in ['prompt_tokens','completion_tokens','total_tokens']):raise RuntimeError('usage integer/range violation')
 if usage['total_tokens']!=usage['prompt_tokens']+usage['completion_tokens']:raise RuntimeError('usage total mismatch')
 if row.get('wire_usage')!=usage or row.get('wire_usage_mismatch'):raise RuntimeError('wire/upstream usage mismatch')
 return usage['completion_tokens']

def audit_phase(directory,arm,before):
 audits=[];all_sum=0
 for concurrency in [1,8,16,32]:
  path=directory/(arm+'-c'+str(concurrency)+'-r1.json');result=json.loads(path.read_text())
  if result['qualification_status']!='passed':raise RuntimeError('matrix cell did not pass')
  warm=result['warmup_records'];rows=result['records']
  if not warm or any(row['outcome']!='success' for row in warm):raise RuntimeError('warmup correctness failure')
  warm_sum=sum(valid_usage(row) for row in warm)
  successes=[row for row in rows if row['outcome']=='success']
  if not successes or any(row['outcome'] not in ['success','refused'] for row in rows):raise RuntimeError('cell outcome failure')
  measured=sum(valid_usage(row) for row in successes)
  native=result['native_counters_after']['llamacpp:tokens_predicted_total']-result['native_counters_before']['llamacpp:tokens_predicted_total']
  if measured!=native or measured!=result['native_predicted_token_delta'] or result['summary']['wire_usage_mismatches']:raise RuntimeError('full native/usage reconciliation failed')
  all_sum+=warm_sum+measured;audits.append({'file':str(path),'concurrency':concurrency,'warmup_successes':len(warm),'successes':len(successes),'refused':sum(row['outcome']=='refused' for row in rows),'warmup_completion_sum':warm_sum,'measured_completion_sum':measured,'native_measured_completion_delta':native,'all_successes_authoritative':True,'all_public_usage_matches':True})
 after=idle();native_all=after['llamacpp:tokens_predicted_total']-before['llamacpp:tokens_predicted_total']
 if native_all!=all_sum:raise RuntimeError('phase warmup+measured native/usage mismatch')
 return {'arm':arm,'cells':audits,'native_before':before,'native_after':after,'native_all_completion_delta':native_all,'authoritative_all_completion_sum':all_sum,'all_successes_authoritative':True,'all_warmup_wire_usage_matches':True}

try:
 actual={key:hashlib.sha256(path.read_bytes()).hexdigest() for key,path in [('runner',RUNNER),('matrix',MATRIX),('tests',TESTS)]}
 if actual!=EXPECTED:raise RuntimeError('frozen tooling mismatch')
 spec=importlib.util.spec_from_file_location('rig6_qualification',RUNNER);q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
 corpus=(MATRIX.parent/'corpus.jsonl').read_bytes()
 manifests={arm:q.load_provenance(RUN/(arm+'-provenance.json'),corpus) for arm in ['baseline','candidate']}
 comparison=q.compare(*[{'provenance':manifests[arm],'limits':{},'summary':{'successful_output_tokens_per_second':None}} for arm in ['baseline','candidate']],factors=('slots','runtime_flags','admission'))
 a,b=manifests['baseline'],manifests['candidate']
 if set(a['runtime_flags'])!=set(b['runtime_flags']):raise RuntimeError('runtime flag keyset mismatch')
 differences={key:[a['runtime_flags'][key],b['runtime_flags'][key]] for key in a['runtime_flags'] if a['runtime_flags'][key]!=b['runtime_flags'][key]}
 if differences!={'-c':['32768','65536'],'--parallel':['1','2']}:raise RuntimeError('runtime flag difference outside exact geometry whitelist')
 for arm,n in [('baseline',1),('candidate',2)]:
  p=manifests[arm]
  if p['binary_sha256']!='038e96fb23cab83fdbb7122df52ffda22e95daef59d316b64f3ad74967ba1093' or p['slots']!=n or p['gpu_indices']!=[6] or p['context_per_sequence']!=32768:raise RuntimeError('new-code same-GPU geometry mismatch')
  if p['admission']!={'active':n,'waiting_limit':8,'queue_timeout_ms':1000}:raise RuntimeError('admission difference outside declared capacity')
  manifest=RUN/(arm+'-home/models/manifests/prism27b.json')
  if not manifest.exists() or json.loads(manifest.read_text())['sha256']!=p['model_sha256']:raise RuntimeError('prepared private registry missing; registration during formal is refused')
 validation={'observed_at':now(),'tool_sha256':actual,'q_load_both_passed':True,'q_compare_passed':True,'comparison':comparison,'exact_runtime_flag_differences':differences,'allowed_runtime_flag_differences':['-c','--parallel'],'new_power_both_arms':True,'source_controller_sha256':'cf2e750243eaebc0d2616b5b7add77f1474f94ea5c1e5ce74860004f5692ef1f','registries_prepared_no_registration_during_formal':True}
 write(OUT/'preflight-validation.json',validation);STATE['preflight_validation']=str(OUT/'preflight-validation.json');save()
 for round_index,order in enumerate(STATE['order'],1):
  for arm in order:
   index=len(STATE['phases'])+1;phase_tag=TAG+'-p'+str(index)
   phase={'phase':index,'outer_round':round_index,'arm':arm,'tag':phase_tag,'started_at':now(),'status':'switching'};STATE['phases'].append(phase);STATE['status']='running';save();print(json.dumps(phase),flush=True)
   bounded(['python3','-B',str(RUN/'supervisor.py'),'switch',arm],OUT/('phase'+str(index)+'-switch.log'),180)
   power_snapshot(arm,'phase'+str(index)+'-before');before=idle();phase['status']='measuring';save()
   command=['python3','-B',str(MATRIX),'--rig','6','--arms',arm,'--tag',phase_tag,'--seconds','60','--repeats','1','--concurrency','1','8','16','32','--factor','slots','runtime_flags','admission'];phase['command']=command;save()
   bounded(command,OUT/('phase'+str(index)+'-matrix.log'),900)
   phase['status']='strict-usage-audit';save();audit=audit_phase(RUN/phase_tag,arm,before)
   write(OUT/('phase'+str(index)+'-full-usage-validation.json'),audit)
   power_snapshot(arm,'phase'+str(index)+'-after');phase.update(status='passed',finished_at=now(),full_usage_validation=str(OUT/('phase'+str(index)+'-full-usage-validation.json')),native_all_completion_delta=audit['native_all_completion_delta']);save();print(json.dumps(phase),flush=True)
 STATE['status']='passed';STATE['finished_at']=now();STATE['elapsed_seconds']=time.monotonic()-START;save();print(json.dumps({'status':'passed','phases':6,'cells':24,'directory':str(OUT)}),flush=True)
except BaseException as error:
 STATE.update(status='failed',finished_at=now(),elapsed_seconds=time.monotonic()-START,error_type=type(error).__name__,error=str(error),automatic_retry=False)
 if STATE['phases']:STATE['phases'][-1]['status']='failed'
 save();print(json.dumps({'status':'failed','directory':str(OUT),'error_type':type(error).__name__,'error':str(error),'automatic_retry':False}),flush=True);raise
